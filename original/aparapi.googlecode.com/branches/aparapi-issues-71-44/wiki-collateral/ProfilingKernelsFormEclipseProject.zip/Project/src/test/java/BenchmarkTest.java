import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Performance tests
 */
public class BenchmarkTest {
	static final Logger					log			= Logger.getLogger(BenchmarkTest.class);

	private static final int		ITERATION_COUNT	= 3;
	private static final int		K				= 1000;
	private static final int		M				= K * K;

	private final static int[]	N				= new int[] { 1, 1 * M, 8 * M, 16 * M, 32 * M, 64 * M };

	private AlgorithmImplementations				api;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		api = new AlgorithmImplementations();
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {}


	/** Cost of host-device communication using integer arrays of various sizes */
	@Test
	public final void copyInOut() {

		// Iterate I_COUNT times and take the mean of the execution times
		for (int i = 0; i < ITERATION_COUNT; i++) {
			log.info("iteration: " + i);
			
			for (int j = 0; j < N.length; j++) {
				log.info("array size: " + N[j]);
				int[] in = fillOrdinal(new int[N[j]]);
				
				// your trace start
				@SuppressWarnings("unused")
				int[] out = api.copyInOutIntGpu(in);
				// your trace end
				log.info("your performance data");
			}
		}
	}
	
	private int[] fillOrdinal(int[] a) {
		for (int i = 0; i < a.length; i++) {
			a[i] = i + 1;
		}
		return a;
	}
}
