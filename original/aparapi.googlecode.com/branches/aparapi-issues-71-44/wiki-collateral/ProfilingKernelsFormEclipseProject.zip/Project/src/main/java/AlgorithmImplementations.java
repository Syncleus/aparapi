import com.amd.aparapi.Kernel;

public class AlgorithmImplementations {
	@SuppressWarnings("unused")
	private Kernel.EXECUTION_MODE	executionMode	= Kernel.EXECUTION_MODE.GPU;

	public int[] copyInOutIntGpu(final int[] in) {
		// start your time trace
		final int[] out = new int[in.length];

		Kernel kernel = new Kernel() {
			@Override
			public void run() {
				int i = getGlobalId();
				int value = in[i];
				value++;
				out[i] = value;
			}
		};
		// kernel.setExecutionMode(executionMode);
		kernel.execute(in.length).dispose();

		// end your time trace
		return out;
	}
}
