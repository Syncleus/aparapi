java \
 -Djava.library.path=../.. \
 -classpath ../../aparapi.jar:info.jar \
 com.amd.aparapi.sample.info.Main
