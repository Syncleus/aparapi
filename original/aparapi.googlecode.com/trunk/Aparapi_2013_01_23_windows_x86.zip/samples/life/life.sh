java\
 -Djava.library.path=../..\
 -Dcom.amd.aparapi.executionMode=$1\
 -classpath ../../aparapi.jar:life.jar\
 com.amd.aparapi.sample.life.Main
